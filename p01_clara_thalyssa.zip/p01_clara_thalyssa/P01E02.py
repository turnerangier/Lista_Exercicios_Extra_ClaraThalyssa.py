numero1 = float(input("Digite o Primeiro Numero: "))
numero2 = float(input("Digite o Segundo Numero: "))

print("A Soma é:", numero1+numero2)