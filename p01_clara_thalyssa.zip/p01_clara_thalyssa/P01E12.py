altura = float(input("Digite a altura: "))
pesoidealh = (72.7*altura) - 58
pesoidealm = (62.1*altura) - 44.7

print("O peso ideal para homens é:",pesoidealh)
print("O peso ideal para mulheres é:",pesoidealm)