tempF = float(input("Digite a temperatura em Fahrenheit: "))
calculo = 5*((tempF-32)/9)

print("A temperatura em Celsius é:",calculo)