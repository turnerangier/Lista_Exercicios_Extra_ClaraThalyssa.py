vhora = float(input("Digite quanto ganha por hora: " ))
htrab = float(input("Digite as horas trabalhadas no mes: "))
salariob = vhora*htrab
imposto = (salariob * 0.11)
inss = (salariob * 0.08)
sindicato = (salariob * 0.05)
descontos = imposto + inss + sindicato
salariol = (salariob - descontos)

print("Salário Bruto R$:",salariob)
print("IR (11%) R$: ",imposto)
print("INSS (8%): R$",inss)
print("Sindicato (5%): R$",sindicato)
print("Salário Liquido: R$",salariol)

