num1 = int(input("Digite um numero inteiro: "))
num2 = int(input("Digite outro numero inteiro: "))
num3 = float(input("Digite um numero real: "))

calculonum1 = (num1*2) * (num2/2)
calculonum2 = (num1*3) + num3
calculonum3 = (num3 **3)

print("O produto do dobro do primeiro com metade do segundo é:",calculonum1)
print("A soma do triplo do primeiro com o terceiro é:",calculonum2)
print("O numero ao cubo é:",calculonum3)
