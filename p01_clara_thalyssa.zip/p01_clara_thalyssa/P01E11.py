altura = float(input("Digite a altura: "))
pesoideal = (72.7*altura) - 58

print("O peso ideal é:",pesoideal)