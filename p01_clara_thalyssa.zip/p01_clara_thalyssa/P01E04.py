metros = float(input("Digite o valor em metros: "))
calculo = metros*100

print("O valor em centimetros é:",calculo)


