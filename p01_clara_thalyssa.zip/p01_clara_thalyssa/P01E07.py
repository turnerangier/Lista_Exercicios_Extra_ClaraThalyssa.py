vhora = float(input("Digite quanto ganhar por hora: " ))
htrab = float(input("Digite as horas trabalhadas: "))
salario = vhora*htrab

print("O seu salario no mes é:",salario)
