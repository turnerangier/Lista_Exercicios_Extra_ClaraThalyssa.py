limite_quilos = 50  
multa = 4
peso = float(input("Digite o peso de peixes (em quilos): "))

if peso > limite_quilos:
    excesso = peso - limite_quilos 
    multa = excesso * multa
else:
    excesso = 0
    multa = 0
    
print("Peso:",peso)
print("Excesso de peso:",excesso)
print("Multa a pagar:",multa)