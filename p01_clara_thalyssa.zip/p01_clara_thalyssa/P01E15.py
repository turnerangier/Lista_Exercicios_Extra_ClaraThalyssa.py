import math
area = float(input("Digite a area em metros: "))
precolata = 80
litros = (area/3)
latas_necessaria = math.ceil(litros/18)
precototal = (latas_necessaria*precolata)

print("Quantidade de latas a serem compradas:",latas_necessaria)
print("Preço total:",precototal)