
import math
area = float(input("Digite a area em metros: "))

precolata = 80
litrolata = 18
litrogalao = 3.6
precogalao = 25
litros = (area/6*1.1)
latas_necessaria = math.ceil(litros/litrolata)
preco1 = (latas_necessaria*precolata)

galoes = math.ceil(litros/litrogalao)
preco2 = (galoes*precogalao)

latas2 = int(litros/litrolata)
desperdicio = (litros - latas2 * litrolata)
galoes2 = math.ceil(desperdicio/litrogalao)
preco3 = (latas2 * precolata + galoes2 * precogalao)

print("Apenas latas de 18 litros:",latas_necessaria)
print("Preço total:",preco1)
print("Apenas galões de 3,6 litros:",galoes)
print("Preço total:",preco2)
print("Mistura latas e galões:",latas2,"e",galoes2)
print("Preço total:",preco3)



