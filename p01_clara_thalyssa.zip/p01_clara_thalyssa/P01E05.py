raio = float(input("Digite o Raio do circulo: "))
area = (raio*raio)*3.14

print("A area é:",area)