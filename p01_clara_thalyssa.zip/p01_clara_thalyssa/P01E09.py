tempC = float(input("Digite a temperatura em Celsius: "))
calculo = (9/5)*tempC+32

print("A temperatura em Fahrenheit é:",calculo)