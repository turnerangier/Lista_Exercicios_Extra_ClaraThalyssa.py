numero = input("Coloque um numero: ")
print("O numero informado foi:",numero)