lado = float(input("Digite o valor do LADO: "))
area = (lado*lado)
area2 = (lado*lado)*2

print("A area do quadrado é:",area)
print("O dobro da area é:",area2)
