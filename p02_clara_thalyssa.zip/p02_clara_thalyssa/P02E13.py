hora = float(input("Digite o valor da sua hora trabalhada: "))
qtd = float(input("Digite a quantidade de horas: "))

salario = hora*qtd

if salario <= 900:
    inss = (salario*0.10)
    fgts = (salario*0.11)
    totald = inss
    liquido = salario-totald
    
    print("Salario Bruto:",salario)
    print("(-) INSS ( 10%):",inss)
    print("FGTS ( 11%):",fgts)
    print("Total desconto:",totald)
    print("Salario liquido:",liquido)
   
elif salario <= 1500:
    inss = (salario*0.10)
    ir = (salario*0.05)
    fgts = (salario*0.11)
    totald = inss+ir
    liquido = salario-totald
    
    print("Salario Bruto:",salario)
    print("(-) IR ( 5%):",ir)
    print("(-) INSS ( 10%):",inss)
    print("FGTS ( 11%):",fgts)
    print("Total desconto:",totald)
    print("Salario liquido:",liquido)
 
elif salario <= 2500:
    inss = (salario*0.10)
    ir = (salario*0.10)
    fgts = (salario*0.11)
    totald = inss+ir
    liquido = salario-totald
    
    print("Salario Bruto:",salario)
    print("(-) IR ( 10%):",ir)
    print("(-) INSS ( 10%):",inss)
    print("FGTS ( 11%):",fgts)
    print("Total desconto:",totald)
    print("Salario liquido:",liquido)

elif salario > 2500:

    inss = (salario*0.10)
    ir = (salario*0.20)
    fgts = (salario*0.11)
    totald = inss+ir
    liquido = salario-totald
    
    print("Salario Bruto:",salario)
    print("(-) IR ( 20%):",ir)
    print("(-) INSS ( 10%):",inss)
    print("FGTS ( 11%):",fgts)
    print("Total desconto:",totald)
    print("Salario liquido:",liquido)
