numero1 = float(input("Digite um numero: "))
numero2 = float(input("Digite outro numero: "))
print("Qual operação deseja realizar: ")
operacao = float(input("1-SOMA, 2-MULT, 3-DIVISAO, 4-SUBTRAÇÃO: "))
soma = numero1+numero2
mult = numero1*numero2
div = numero1/numero2
sub = numero1-numero2

if operacao == 1:
    print("A Soma é:",soma)
    if soma % 2 == 0:
        print("O numero é par")
    else:
        print("O numero é ímpar")

    if soma > 0:
        print("o numero é positivo")  
    else: 
        print("o numero é negativo")  

    if soma == int(soma):    
        print("O numero é inteiro")
    else: 
        print("O numero é decimal") 

if operacao == 2:
    print("A Multiplicação é:",mult)
    if mult % 2 == 0:
        print("O numero é par")
    else:
        print("O numero é ímpar")
    if mult > 0:
        print("o numero é positivo")  
    else: 
        print("o numero é negativo")               
    if mult == int(mult):    
        print("O numero é inteiro")
    else: 
        print("O numero é decimal")

if operacao == 3:
    print("A Divisão é:",div)
    if div % 2 == 0:
        print("O numero é par")
    else:
        print("O numero é ímpar")
    if div > 0:
        print("o numero é positivo")  
    else: 
        print("o numero é negativo")               
    if div == int(div):    
        print("O numero é inteiro")
    else: 
        print("O numero é decimal")

if operacao == 4:
    print("A Subtração é:",sub)
    if sub % 2 == 0:
        print("O numero é par")
    else:
        print("O numero é ímpar")
    if sub > 0:
        print("o numero é positivo")  
    else: 
        print("o numero é negativo")               
    if sub == int(sub):    
        print("O numero é inteiro")
    else: 
        print("O numero é decimal")                             
        
   
