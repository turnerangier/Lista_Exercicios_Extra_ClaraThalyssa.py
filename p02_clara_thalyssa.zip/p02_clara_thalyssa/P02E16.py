lado1 = float(input("Digite o Lado 1: "))
lado2 = float(input("Digite o Lado 2: "))
lado3 = float(input("Digite o Lado 3: "))

triangulo = lado1+lado2

if (lado1 + lado2 > lado3) and (lado1 + lado3 > lado2) and (lado2 + lado3 > lado1):
        print("É um triangulo")

if lado1 == lado2 == lado3:
        print("Triangulo Equilatero")
elif lado1 == lado2 or lado1 == lado3 or lado2 == lado3:
        print("Triangulo Isosceles")
else:
        print("Triangulo Escaleno)")

