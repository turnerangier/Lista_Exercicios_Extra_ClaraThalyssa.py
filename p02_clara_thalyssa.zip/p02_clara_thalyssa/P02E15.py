nota1 = float(input("Digite a Nota 1: "))
nota2 = float(input("Digite a Nota 2: "))
media = (nota1+nota2)/2

if media >= 9:
    print("Nota 1:",nota1)
    print("Nota 2:",nota2)
    print("media:",media)
    print("A")
    print("APROVADO")
elif media >= 7.5:
    print("Nota 1:",nota1)
    print("Nota 2:",nota2)
    print("media:",media)
    print("B")
    print("APROVADO")
elif media <= 6:
    print("Nota 1:",nota1)
    print("Nota 2:",nota2)
    print("media:",media)
    print("D")
    print("REPROVADO")
elif media <= 4:
    print("Nota 1:",nota1)
    print("Nota 2:",nota2)
    print("media:",media)
    print("E")
    print("REPROVADO")
   