valor = int(input("Digite o valor para saque que esteja entre 10 e 600: "))

if valor > 10 or valor < 600:
    
    nota100 = valor // 100
    resto = valor % 100

    nota50 = resto // 50
    resto = resto % 50

    nota10 = resto // 10
    resto = resto % 10

    nota5 = resto // 5
    nota1 = resto % 5

    if nota100 > 0:
        print("nota(s) de 100:",nota100)
    if nota50 > 0:
        print("nota(s) de 50:",nota50)
    if nota10 > 0:
        print("nota(s) de 10:",nota10)
    if nota5 > 0:
        print("nota(s) de 5:",nota5)
    if nota1 > 0:
        print("nota(s) de 1:",nota1)
