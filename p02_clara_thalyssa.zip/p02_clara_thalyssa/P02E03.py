valor = float(input("Digite um valor: "))

if valor > 0:
    print("Valor positivo:",valor)
elif valor == 0:
    print("Valor neutro:",valor)
else:
    print("Valor negativo:",valor)
