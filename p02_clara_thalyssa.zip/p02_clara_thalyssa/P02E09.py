preco1 = float(input("Digite o primeiro preço: "))
preco2 = float(input("Digite o segundo preço: "))
preco3 = float(input("Digite o terceiro preço: "))

menor = preco1

if preco2 < menor:
    menor = preco2
if preco3 < menor:
    menor = preco3

print("Compre o produto com valor:",menor)