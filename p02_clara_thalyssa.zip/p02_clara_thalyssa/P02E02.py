num1 = float(input("Digite um numero: "))
num2 = float(input("Digite outro numero: "))

if num1 > num2:
 print("O maior numero:",num1)
else:
    print("O maior numero:",num2)       
            