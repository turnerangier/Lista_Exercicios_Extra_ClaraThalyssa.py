carne = float(input("Digite a carne: 1- File Duplo, 2- Alcatra, 3- Picanha: "))
kg = kg = float(input("Digite a quantidade (KG): "))
cartao = float(input("Cartão 1-SIM, 2-NÃO: "))

if cartao == 1:
    if kg > 5:

        if carne == 1:
            calc3 = (kg*5.80) - kg*5.80*0.05
            print("Tipo: File duplo")
            print("Quantidade:",kg)
            print("Preço total:",kg*5.80)
            print("Cartão")
            print("Desconto de:",kg*5.80*0.05)
            print("Valor a ser pago:",calc3)
            
        if carne == 2:
            calc4 = (kg*6.80) - kg*6.80*0.05
            print("Tipo: Alcatra")
            print("Quantidade:",kg)
            print("Preço total:",kg*6.80)
            print("Cartão")
            print("Desconto de:",kg*6.80*0.05)
            print("Valor a ser pago:",calc4)
            
    
        if carne == 3:
            calc5 = (kg*7.80) - kg*7.80*0.05
            print("Tipo: Picanha")
            print("Quantidade:",kg)
            print("Preço total:",kg*7.80)
            print("Cartão")
            print("Desconto de:",kg*7.80*0.05)
            print("Valor a ser pago:",calc5)
            
    if kg <=5:

        if carne == 1:
            calc = kg*4.90 - kg*4.90*0.05
            print("Tipo: File duplo")
            print("Quantidade:",kg)
            print("Preço total:",kg*4.90)
            print("Cartão")
            print("Desconto de:",kg*4.90*0.05)
            print("Valor a ser pago:",calc)
    
        if carne == 2:
            calc1 = kg*5.90 - kg*5.90*0.05
            print("Tipo: Alcantra")
            print("Quantidade:",kg)
            print("Preço total:",kg*5.90)
            print("Cartão")
            print("Desconto de:",kg*5.90*0.05)
            print("Valor a ser pago:",calc1)
    
        if carne == 3:
            calc2 = kg*6.90 - kg*6.90*0.05
            print("Tipo: Picanha")
            print("Quantidade:",kg)
            print("Preço total:",kg*6.90)
            print("Cartão")
            print("Desconto de:",kg*6.90*0.05)
            print("Valor a ser pago:",calc2) 

if cartao == 2:
    if kg > 5:

        if carne == 1:
            calc3 = (kg*5.80)
            print("Tipo: File Duplo")
            print("Quantidade:",kg)
            print("Valor a ser pago:",calc3)
    
        if carne == 2:
            calc4 = (kg*6.80)
            print("Tipo: Alcatra")
            print("Quantidade:",kg)
            print("Valor a ser pago:",calc4)
    
        if carne == 3:
            calc5 = (kg*7.80)
            print("Tipo: Picanha")
            print("Quantidade:",kg)
            print("Valor a ser pago:",calc5)     

    if kg <=5:

        if carne == 1:
            calc = kg*4.90
            print("Tipo: File Duplo")
            print("Quantidade:",kg)
            print("Valor a ser pago:",calc)
    
        if carne == 2:
            calc1 = kg*5.90
            print("Tipo: Alcatra")
            print("Quantidade:",kg)
            print("Valor a ser pago:",calc1)
    
        if carne == 3:
            calc2 = kg*6.90
            print("Tipo: Picanha")
            print("Quantidade:",kg)
            print("Valor a ser pago:",calc2) 
    




