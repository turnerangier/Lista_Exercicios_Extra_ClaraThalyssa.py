dias = float(input("1-Domingo, 2- Segunda, 3-Terça, 4- Quarta, 5- Quinta, 6- Sexta, 7- Sabado: "))

if dias == 1:
    print("Domingo")
elif dias == 2:
    print("Segunda") 
elif dias == 3:
    print("Terça") 
elif dias == 4:
    print("Quarta") 
elif dias == 5:
    print("Quinta") 
elif dias == 6:
    print("Sexta") 
elif dias == 7:
    print("Sabado") 
else:
    print("Valor Invalido")