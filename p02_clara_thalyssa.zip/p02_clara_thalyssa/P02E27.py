litros = float(input(" Digite os litros: "))
tipo = input("A-álcool, G-gasolina: ")
             
if tipo == "A":
    if litros<=20:
        preco1 = litros*1.90
        preco2 = preco1 *(1 - 0.03)
        print("valor a ser pago: ",preco2)
    else:
        preco1 = litros*1.90
        preco2 = preco1 *(1 - 0.05)
        print("valor a ser pago: ",preco2)
if tipo == "G":
    if litros<=20:
        preco1 = litros *2.50
        preco2 = preco1 *(1 - 0.04)
        print("valor a ser pago: ",preco2)
    else:
        preco1 = litros *2.50
        preco2 = preco1 *(1 - 0.06)
        print("valor a ser pago: ",preco2)


