salario = float(input("Digite seu salario: "))

if salario <= 280:
    ajuste1 = (salario*0.2)+salario
    print("Salario atual:",salario)
    print("Percentual: 20%")
    print("Aumento:",salario*0.21)
    print("Novo salario: ",ajuste1)
   
elif salario <= 700:
    ajuste2 = (salario*0.15)+salario
    print("Salario atual:",salario)
    print("Percentual: 15%")
    print("Aumento:",salario*0.15)
    print("Novo salario: ",ajuste2)
   
elif salario <= 1500:
    ajuste3 = (salario*0.10)+salario
    print("Salario atual:",salario)
    print("Percentual: 10%")  
    print("Aumento:",salario*0.10)
    print("Novo salario: ",ajuste3)

if salario > 1500:
    ajuste4 = (salario*0.05)+salario
    print("Salario atual:",salario)
    print("Percentual: 5%")
    print("Aumento:",salario*0.05)
    print("Novo salario: ",ajuste4)
   
   
   
   

