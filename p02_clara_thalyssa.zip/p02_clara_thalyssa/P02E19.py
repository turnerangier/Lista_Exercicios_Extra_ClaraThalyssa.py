from datetime import datetime

data = input("Digite uma data no formato dd/mm/aaaa: ")
try:
    data = datetime.strptime(data, "%d/%m/%Y")
    print("A data é valida:",data)
except ValueError:
    print("A data é invalida:",data)
