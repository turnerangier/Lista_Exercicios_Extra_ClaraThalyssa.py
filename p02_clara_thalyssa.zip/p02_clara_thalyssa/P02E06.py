nota1 = float(input("Digite a Nota 1: "))
nota2 = float(input("Digite a Nota 2: "))
media = (nota1+nota2)/2

if media >7:
    print("Aprovado")
elif media <7:
    print("Reprovado")
elif media == 7:
    print("Aprovado com Distinção") 
