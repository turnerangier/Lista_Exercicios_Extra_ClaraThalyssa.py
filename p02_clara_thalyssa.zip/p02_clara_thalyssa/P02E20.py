num = int(input("Digite um num inteiro que seja menor que 1000: "))

if 0 < num < 1000:
    centenas = num // 100
    dezenas = (num % 100) // 10
    unidades = num % 10

    partes = []

    if centenas > 0:
        if centenas == 1:
            partes.append("1 centena")
        else:
            partes.append(str(centenas) + " centenas")

    if dezenas > 0:
        if dezenas == 1:
            partes.append("1 dezena")
        else:
            partes.append(str(dezenas) + " dezenas")

    if unidades > 0:
        if unidades == 1:
            partes.append("1 unidade")
        else:
            partes.append(str(unidades) + " unidades")

    if len(partes) == 1:
        resultado = partes[0]
    elif len(partes) == 2:
        resultado = partes[0] + " e " + partes[1]
    else:
        resultado = partes[0] + ", " + partes[1] + " e " + partes[2]
    print(str(num) + " = " + resultado)

