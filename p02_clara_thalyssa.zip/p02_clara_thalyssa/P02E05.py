letra = input("Digite uma letra: ")

if letra in "aeiouAEIOU":
   print("Vogal")
else:
    print("Consoante")
