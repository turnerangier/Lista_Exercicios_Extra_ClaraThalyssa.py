fruta1= float(input("Digite a quantidade de Morangos (KG): "))
fruta2= float(input("Digite a quantidade de Maças (KG): "))

kg = fruta1+fruta2
calc = fruta1*2.50 + fruta2*1.80
calc2 = fruta1*2.20 + fruta2*1.50

if kg > 8 or calc2 > 25:
    calc3 = calc2-(calc2*0.1)
    print("Valor a ser pago:",calc3)
    
if kg <=5:
    print("Valor a ser pago:",calc)
if kg < 8:
    print("Valor a ser pago:",calc2)



