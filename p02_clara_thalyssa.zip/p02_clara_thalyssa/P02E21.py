nota1 = float(input("Digite a Nota 1: "))
nota2 = float(input("Digite a Nota 2: "))
media = (nota1+nota2)/2

if media == 10:
    print("Aprovado com Distinção") 
    print("media:",media)
elif media >=7:
    print("Aprovado")
    print("media:",media)
elif media <7:
    print("Reprovado")
    print("media:",media)
