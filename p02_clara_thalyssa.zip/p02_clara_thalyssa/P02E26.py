pergunta1 = float(input("Telefonou para a vítima? 1-SIM 0-NÃO: "))
pergunta2 = float(input("Esteve no local do crime?: 1-SIM 0-NÃO: "))
pergunta3 = float(input("Mora perto da vítima?: 1-SIM 0-NÃO: "))
pergunta4 = float(input("Devia para a vítima?: 1-SIM 0-NÃO: "))
pergunta5 = float(input("Já trabalhou com a vítima?: 1-SIM 0-NÃO: "))

soma = pergunta1+pergunta2+pergunta3+pergunta4+pergunta5

if soma == 2:
    print("Suspeita")
if soma==3 or soma==4:
    print("Cumplice")
if soma ==5:  
    print("Assassino")
if soma < 2:
    print("Inocente")


