print("Digite o turno que voce estuda")
turno = input("M-matutino ou V-Vespertino ou N-Noturno: ")

if turno == "M":
    print("Bom Dia!")
elif turno == "V":
    print("Boa Tarde!") 
elif turno == "N":
    print("Boa Noite!") 
else:
    print("Valor Inválido!")