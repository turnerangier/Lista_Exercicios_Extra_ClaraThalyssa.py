tamanho = float(input("Digite o tamanho do arquivo em MB: "))
velocidade = float(input("Digite a velocidade do link em Mbps: "))
velocidadeMbps = (velocidade/8)
tempo = (tamanho/velocidadeMbps)
tempoMinutos = (tempo/60)

print("O tempo em minutos é:",tempoMinutos)