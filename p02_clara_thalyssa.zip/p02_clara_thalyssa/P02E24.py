numero = float(input("Digite um numero: "))


arredondar = round(numero)

if numero == int(numero):
    print("o numero é inteiro:",arredondar)
else:
    print("numero decimal",arredondar)    
