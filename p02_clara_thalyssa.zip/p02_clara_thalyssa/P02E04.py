letra = input("Digite a letra F ou M: ")

if letra == "F":
    print("Feminino")
elif letra == "M":
    print("Masculino")
else:
    print("Sexo invalido")