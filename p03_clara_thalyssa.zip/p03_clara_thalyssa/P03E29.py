preco = 1.99
print("Lojas Quase Dois - Tabela de preços")

for quantidade in range(1, 51):
    total = quantidade * preco
    print(quantidade,"- R$",total)
