num = int(input("Digite um numero: "))

if num > 0:
    fatorial = 1
    print(str(num) + "! =", end=" ")
    for c in range(num, 0, -1):
        print(c, end="")
        fatorial *= c

        if c > 1:
            print(".", end="")
print(" =",fatorial)
