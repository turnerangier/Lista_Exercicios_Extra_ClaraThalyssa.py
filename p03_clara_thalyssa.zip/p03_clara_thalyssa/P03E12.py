num = int(input("Digite um numero entre 1 e 10: "))

if 1 <= num <= 10:
    print("Tabuada de:",num)
    for i in range(1, 11):
        resultado = num * i
        print(num,"X",i, "=", resultado)

else:
    print("escolha um numero do intervalo")