cds = int(input("Digite a quantidade de cds: "))

total = 0
for i in range(1, cds + 1):
    valor_cd = float(input("Digite o valor pago pelo CD:"))
    total += valor_cd

media_gasto = (total/cds)

print("Valor total investido na coleção:",total)
print("Valor medio gasto por CD:",media_gasto)
