turmas = int(input("Digite o numero de turmas: "))
ntotalalunos = 0

for i in range(1,turmas + 1):
        alunos = int(input("Digite o numero de alunos da turma ate 40 alunos: "))
        if alunos <= 40:
            ntotalalunos += alunos
        
media = (ntotalalunos/turmas)
print("A media de alunos por turma é:",media)