numero = int(input("Digite um numero inteiro: "))

if numero < 2:
    print("Não é um numero primo")
else:
    primo = True
    for i in range(2, int(numero**0.5) + 1):
        if numero % i == 0:
            primo = False
            break
    if primo:
        print("Ele é um numero primo")
    else:
        print("Ele não é um numero primo")
