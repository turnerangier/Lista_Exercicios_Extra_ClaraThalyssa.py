for b in range(1, 21):
    print(b)

for b in range(1, 21):
    print(b, end=' ')
