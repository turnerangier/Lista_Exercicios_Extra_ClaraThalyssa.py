while True:
    n = int(input("Digite um número inteiro positivo menor que 16 para calcular o fatorial: "))
    if 0 <= n < 16:
        fatorial = 1
        for i in range(1, n + 1):
            fatorial *= i
        print(f"{n}! = {fatorial}")
    else:
        print("Número inválido. Tente novamente.")

    if input("Quer calcular outro fatorial? (s/n): ").lower() != 's':
        break
