while True:
    pop_a = int(input("População do país A: "))
    pop_b = int(input("População do país B: "))
    taxa_a = float(input("Taxa anual de crescimento de A (%): "))
    taxa_b = float(input("Taxa anual de crescimento de B (%): "))

    anos = 0
    while pop_a < pop_b:
        pop_a *= 1 + taxa_a / 100
        pop_b *= 1 + taxa_b / 100
        anos += 1

    print(f"Serão necessários {anos} anos para A ultrapassar ou igualar B.")

    if input("Quer repetir? (s/n): ").lower() != "s":
        break
