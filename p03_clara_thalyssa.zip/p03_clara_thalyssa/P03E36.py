num = int(input("Digite um numero entre 1 e 10: "))

if 1 <= num <= 10:
    inicio = int(input("Digite o valor inicial da tabuada: "))
    fim = int(input("Digite o valor final da tabuada: "))
    if inicio <= fim:
        print("Montar a tabuada de:",num)
        print("Começar por:",inicio)
        print("Terminar em:",fim)
        for i in range(inicio, fim + 1):
            resultado = num * i
            print(num, "X",i, "=",resultado)
    else:
        print("O valor inicial deve ser menor ou igual ao valor final")


