cardapio = {
    100: 1.20,
    101: 1.30,
    102: 1.50,
    103: 1.20,
    104: 1.30,
    105: 1.00
}

total = 0

while True:
    codigo = int(input("Código (0 para sair): "))
    if codigo == 0:
        break
    if codigo in cardapio:
        qtd = int(input("Quantidade: "))
        total += cardapio[codigo] * qtd
    else:
        print("Código inválido.")

print(f"Total: R$ {total:.2f}")
