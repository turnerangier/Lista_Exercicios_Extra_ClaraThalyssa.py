num1 = 0
num2 = 0
num3 = 0
num4 = 0
while True:
    numero = int(input("Digite um numero positivo ou digite um negativo para encerrar: "))

    if numero < 0:
        break
    if 0 <= numero <= 25:
        num1 += 1
    elif 26 <= numero <= 50:
        num2 += 1
    elif 51 <= numero <= 75:
        num3 += 1
    elif 76 <= numero <= 100:
        num4 += 1
    else:
        print("numero negativo")
print("Quantidade no intervalo [0-25]:",num1)
print("Quantidade no intervalo [26-50]:",num2)
print("Quantidade no intervalo [51-75]:",num3)
print("Quantidade no intervalo [76-100]:",num4)
