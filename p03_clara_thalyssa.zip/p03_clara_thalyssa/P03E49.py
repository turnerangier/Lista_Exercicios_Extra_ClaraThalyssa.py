n = int(input("Digite o número de termos: "))

soma = 0
den = 1

for i in range(1, n + 1):
    termo = i / den
    soma += termo
    den += 2

print(f"Soma da série: {soma:.2f}")
