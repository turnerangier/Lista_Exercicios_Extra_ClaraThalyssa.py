divida = float(input("Digite o valor da divida: "))

print("Valor da Dívida  Valor dos Juros  Quantidade de Parcelas  Valor da Parcela")
parcelas   = [1, 3, 6, 9, 12]

for qtd in parcelas:
    if  qtd == 1:
        juros = 0
    elif qtd == 3:
        juros = 10
    elif qtd == 6:
        juros = 15
    elif qtd == 9:
        juros = 20
    elif qtd == 12:
        juros = 25
    valor_juros = divida * (juros/100)
    valor_total = divida + valor_juros
    valor_parcela = (valor_total/qtd)

    print("R$",valor_total, "       R$", valor_juros,"             "    ,qtd ,"                     R$",valor_parcela)
  