nome = str(input('Informe o nome do atleta:'))
list = []

for r in range(7):
    nota= float(input('informa a '+ str (r + 1) + ' ° nota'))
    list.append(nota)


print("Resultado Final:")
print("Nome do atleta: ", nome)
print("Melhor nota: ", max(list))
print("Pior nota: ", min(list))

list.remove(max(list))
list.remove(min(list))
media = sum(list) / 5
print("Media: ", round(media, 2))