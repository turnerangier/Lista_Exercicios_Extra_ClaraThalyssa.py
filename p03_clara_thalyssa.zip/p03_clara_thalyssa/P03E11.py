num1 = int(input("Digite o primeiro número: "))
num2 = int(input("Digite o segundo número: "))

nummenor = min(num1, num2)
nummaior = max(num1, num2)
soma = 0 

for numero in range(nummenor + 1, nummaior):
    soma += numero
print("Soma:",soma)