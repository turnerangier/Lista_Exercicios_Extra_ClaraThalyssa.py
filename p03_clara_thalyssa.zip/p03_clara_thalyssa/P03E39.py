altonumero = 0
altoaltura = 0
baixonumero = 0
baixoaltura = 500 

for i in range(1, 11):
    numero = int(input("Digite o numero do aluno: "))
    altura = float(input("Digite a altura do aluno (em cm): "))
    if altura > altoaltura:
        altoaltura = altura
        altonumero = numero
    if altura < baixoaltura:
        baixoaltura = altura
        baixonumero = numero

print("Aluno mais alto: numero", altonumero, "altura:",altoaltura, "cm")
print("Aluno mais baixo: numero:º",baixonumero, "altura:",baixoaltura, "cm")
