numero = input("Digite um numero inteiro positivo: ")

invertido = numero[::-1]
print("Número invertido:",invertido)


