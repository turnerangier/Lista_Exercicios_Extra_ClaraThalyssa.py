
while True:
        usuario = input("Digite o nome de usuario: ")
        senha = input("Digite sua senha: ")
        if usuario!=senha:

            print("Usuario e senha validos")
            break

        else:
             print("usuario e senha nao podem ser iguais") 