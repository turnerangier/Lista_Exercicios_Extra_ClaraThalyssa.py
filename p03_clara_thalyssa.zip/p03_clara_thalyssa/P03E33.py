soma = 0
quantidade = 0
menor = None
maior = None

print("Digite as temperaturas (digite -999 para encerrar):")

while True:
    temp = float(input("Temperatura: "))
    if temp == -999:
        break

    soma += temp
    quantidade += 1

    if menor is None or temp < menor:
        menor = temp
    if maior is None or temp > maior:
        maior = temp

if quantidade > 0:
    print(f"\nMenor temperatura: {menor}")
    print(f"Maior temperatura: {maior}")
    print(f"Média das temperaturas: {soma / quantidade:.2f}")
else:
    print("Nenhuma temperatura foi informada.")
