
numero = int(input("Numero de pessoas q tem na turma: "))
soma = 0
for i in range(numero):
    idade = int(input("Digite a idade das pessoas: "))

    soma += idade
media = (soma/numero)

print("Media de idade da turma é:",media)
if 0 <= media <= 25:
    print("A turma é jovem")
elif 26 <= media <= 60:
    print("A turma é adulta")
elif media > 60:
    print("A turma é idosa")

