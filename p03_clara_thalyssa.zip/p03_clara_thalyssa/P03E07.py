maior = None
for c in range(5):
    numero = float(input("Digite os numeros: "))
    
    if maior is None or numero > maior:
        maior = numero
print("O maior numero é:",maior)
