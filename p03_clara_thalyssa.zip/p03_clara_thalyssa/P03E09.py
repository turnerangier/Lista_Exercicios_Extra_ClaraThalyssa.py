print("os numeros impares entre 1 e 50: ")
for num in range(1, 51):
    if num % 2 != 0:
        print(num)
