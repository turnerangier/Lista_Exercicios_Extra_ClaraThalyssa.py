preco = 0.18
print("Preço do pão: R$ 0.18")
print("Panificadora Pão de Ontem - Tabela de preços ")

for quantidade in range(1, 51):
    total = quantidade * preco
    print(quantidade,"- R$",total)
