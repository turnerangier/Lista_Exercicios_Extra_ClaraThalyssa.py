n = int(input("Quantos números você vai digitar? "))

numeros = []
for _ in range(n):
    while True:
        num = float(input("Digite um número entre 0 e 1000: "))
        if 0 <= num <= 1000:
            numeros.append(num)
            break
        else:
            print("Número inválido. Tente novamente.")

print(f"Menor valor: {min(numeros)}")
print(f"Maior valor: {max(numeros)}")
print(f"Soma dos valores: {sum(numeros)}")
