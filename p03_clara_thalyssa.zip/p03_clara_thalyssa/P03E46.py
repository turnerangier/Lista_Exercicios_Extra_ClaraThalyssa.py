atletas = []

while True:
    nome = input("Nome do atleta (ou enter para sair): ")
    if nome == "":
        break

    saltos = [float(input(f"{i+1}º salto: ")) for i in range(5)]
    melhor = max(saltos)
    pior = min(saltos)
    media = (sum(saltos) - melhor - pior) / 3

    print(f"\nMelhor salto: {melhor:.1f} m")
    print(f"Pior salto: {pior:.1f} m")
    print(f"Média dos demais saltos: {media:.1f} m\n")

    atletas.append((nome, media))

print("\nResultado final")
for nome, media in atletas:
    print(f"{nome}: {media:.1f} m")
