numero = int(input("Digite a qtd de notas: "))
soma = 0
for i in range(numero):
    nota = float(input("Digite a nota: "))
    
    soma += nota
media = (soma/numero)

print("A media aritmetica das notas é:",media)
