n = int(input("Quantos números você vai digitar? "))

numeros = []
for _ in range(n):
    num = float(input("Digite um número: "))
    numeros.append(num)

print(f"Menor valor: {min(numeros)}")
print(f"Maior valor: {max(numeros)}")
print(f"Soma dos valores: {sum(numeros)}")
