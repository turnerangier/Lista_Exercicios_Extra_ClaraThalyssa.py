numero = int(input("Digite um numero inteiro: "))
if numero < 2:
    print("Não é um numero primo")
else:
    divisores = []
    for i in range(2, int(numero**0.5) + 1):
        if numero % i == 0:
            divisores.append(i)
            if i != numero // i:
                divisores.append(numero // i)
    if len(divisores) == 0:
        print("Ele é um numero primo")
    else:
        divisores = sorted(divisores)
        print("Ele nao é um numero primo. É divisivel por:",divisores)
