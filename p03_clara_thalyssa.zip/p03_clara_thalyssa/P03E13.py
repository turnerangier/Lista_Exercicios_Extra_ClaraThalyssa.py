num = int(input("Digite um número entre 1 e 10: "))

print(f"Tabuada de {num}:")
for i in range(1, 11):
    print(f"{num} X {i} = {num * i}")
