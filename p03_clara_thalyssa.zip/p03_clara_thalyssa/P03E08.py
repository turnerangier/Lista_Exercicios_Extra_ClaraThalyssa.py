num = []
for c in range(5):
    numero = float(input("Digite os numeros: "))
    num.append(numero)
    soma = sum(num)

print("A soma é: ",soma)
print("A media é:",soma/5)
