
total = int(input("Digite o numero total de eleitores: "))
voto1 = 0
voto2 = 0
voto3 = 0
for i in range(total):
    print("Vote no candidato:")
    print("1- candidato 1")
    print("2- candidato 2")
    print("3- candidato 3")
    
    voto = int(input("Seu voto: "))
    if voto == 1:
        voto1 += 1
    elif voto == 2:
        voto2 += 1
    elif voto == 3:
        voto3 += 1

print("Votos no candidato 1:",voto1)
print("Votos no candidato 2:",voto2)
print("Votos no candidato 3:",voto3)
