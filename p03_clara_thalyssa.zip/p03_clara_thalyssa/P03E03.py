
nome = input("Digite o nome de usuario: ")
idade = int(input("Digite sua idade: "))
salario = float(input("Digite seu salario: "))
sexo = str(input("Digite seu sexo - f' ou 'm': "))
estadocivil = str(input("Digite seu estado civil 's', 'c', 'v', 'd': "))

if len(nome)>3:
    print("Nome Valido")
else: 
    print("Nome invalido")
if idade >0 or idade<150:
    print("Idade Valida")
else:
    print("idade invalida")   
if salario > 0:
    print("Salario valido")
else:
    print("Salario invalido")  
if sexo == 'f' or 'm':
    print("Sexo valido")
else:
    print("Sexo invalido")             
if estadocivil == 's' or 'c' or 'v' or 'd':
    print("Estado civil valido")
else:
    print("Estado civil invalido")
