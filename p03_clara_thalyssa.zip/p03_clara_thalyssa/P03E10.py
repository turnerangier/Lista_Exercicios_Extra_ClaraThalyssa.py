num1 = int(input("Digite o primeiro numero: "))
num2 = int(input("Digite o segundo numero: "))

nummenor = min(num1, num2)
nummaior = max(num1, num2)

print("Numeros inteiros entre",num1,"e",num2,":")

for numero in range(nummenor + 1, nummaior):
    print(numero)
