salario = float(input("Digite o salario inicial do funcionário: "))
ano = 1995
percent = 0.015  

for atual in range(1996, 1997):
    aumento = (salario*percent)
    salario += aumento
    percent *= 2

print("Salário atual",salario)
