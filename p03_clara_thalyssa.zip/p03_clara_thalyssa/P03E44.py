v1 = v2 = v3 = v4 = nulo = branco = 0

while True:
    voto = int(input("Voto (1-José, 2-João, 3-Maria, 4-Ana, 5-Nulo, 6-Branco, 0-Fim): "))
    if voto == 0:
        break
    elif voto == 1:
        v1 += 1
    elif voto == 2:
        v2 += 1
    elif voto == 3:
        v3 += 1
    elif voto == 4:
        v4 += 1
    elif voto == 5:
        nulo += 1
    elif voto == 6:
        branco += 1
    else:
        print("Código inválido.")

total = v1 + v2 + v3 + v4 + nulo + branco

print("\nResultado:")
print(f"José: {v1}")
print(f"João: {v2}")
print(f"Maria: {v3}")
print(f"Ana: {v4}")
print(f"Nulos: {nulo}")
print(f"Brancos: {branco}")

if total > 0:
    print(f"% Nulos: {nulo / total * 100:.2f}%")
    print(f"% Brancos: {branco / total * 100:.2f}%")
else:
    print("Nenhum voto computado.")
