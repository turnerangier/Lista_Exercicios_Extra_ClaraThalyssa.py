maior = -1
menor = 999999
cidade_maior = cidade_menor = ""
soma_veic = 0
soma_acid_peq = 0
cont_peq = 0

for i in range(5):
    cod = input("Código da cidade: ")
    veic = int(input("Veículos de passeio: "))
    acid = int(input("Acidentes com vítimas: "))

    soma_veic += veic

    if acid > maior:
        maior = acid
        cidade_maior = cod
    if acid < menor:
        menor = acid
        cidade_menor = cod

    if veic < 2000:
        soma_acid_peq += acid
        cont_peq += 1

print(f"\nMaior índice de acidentes: {maior} (Cidade {cidade_maior})")
print(f"Menor índice de acidentes: {menor} (Cidade {cidade_menor})")
print(f"Média de veículos: {soma_veic / 5:.1f}")
if cont_peq:
    print(f"Média de acidentes (<2000 veículos): {soma_acid_peq / cont_peq:.1f}")
else:
    print("Nenhuma cidade com menos de 2000 veículos.")
