stg1 = input("Digite a primeira: ")
stg2 = input("Digite a segunda: ")

print("String 1:",stg1)
print('Tamanho de "' + stg1 + '":', len(stg1),"caracteres")
print("String 2:",stg2)
print('Tamanho de "' + stg2 + '":', len(stg2),"caracteres")

if len(stg1) == len(stg2):
    print("As duas strings tem o mesmo comprimento.")
else:
    print("As duas strings tem comprimentos diferentes.")

if stg1 == stg2:
    print("As duas strings possuem conteúdo igual.")
else:
    print("As duas strings possuem conteúdo diferente.")
