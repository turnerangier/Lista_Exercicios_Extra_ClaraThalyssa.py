cpfpessoa = str(input("digite o CPF: xxx.xxx.xxx-xx: "))

if len(cpfpessoa) == 14:
    print("CPF correto")
else:  
    print("CPF Incorreto")

