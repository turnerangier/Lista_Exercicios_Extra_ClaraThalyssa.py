from num2words import num2words

numero = int(input("Digite um numero ate 99: "))

if numero <=99:
    numeroextenso = num2words(numero, lang='pt_BR')  
    print(numeroextenso)   
else:
    print("Numero maior que 99")           

