nome = input("Digite o nome: ")
nome2 = nome.upper()[::-1]
print(nome2)