nome = input("Digite o nome: ")
for letra in nome:
    print(letra)