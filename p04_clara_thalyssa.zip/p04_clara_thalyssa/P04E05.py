nome = input("Digite o nome: ")
for i in range(len(nome), -1, -1):
    print(nome[:i])