
meses = {
    "01": "janeiro",
    "02": "fevereiro",
    "03": "março",
    "04": "abril",
    "05": "maio",
    "06": "junho",
    "07": "julho",
    "08": "agosto",
    "09": "setembro",
    "10": "outubro",
    "11": "novembro",
    "12": "dezembro"
}
datadenasc = input("Digite sua data de nascimento (dd/mm/aaaa): ")
dia, mes, ano = datadenasc.split("/")

if mes in meses:
    print("Você nasceu em", dia, "de", meses[mes], "de", ano)

