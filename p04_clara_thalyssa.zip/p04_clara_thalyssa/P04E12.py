numero = str(input("Digite um numero de telefone ate 8 digitos: "))

numero2 = numero.replace('-', '')
if len(numero) == 7:
        numero = '3' + numero
        print("Número com 7 dígitos detectado. Corrigindo com '3' na frente.")
        print(numero)
        

elif len(numero) == 8:
        numero2 = '3' + numero2
        print("Número com 7 dígitos detectado. Corrigindo com '3' na frente.")
        print('3' +numero)
 
 