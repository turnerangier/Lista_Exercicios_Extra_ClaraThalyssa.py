nome = input("Digite o nome: ")
for i in range(1, len(nome) + 1):
    print(nome[:i])