texto = input("Digite uma palavra: ").lower().strip().replace(' ', '')
if texto == texto[::-1]:
    print("Sim, é um palindromo")
else:
    print("Não é palíndromo")