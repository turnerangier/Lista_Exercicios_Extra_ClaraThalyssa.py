consoantes = []
for i in range(10):
    letra = input("Digite uma letra: ").lower()
    if letra.isalpha() and letra not in 'aeiou':
        consoantes.append(letra)
print("Consoantes:", consoantes)
print("Quantidade:", len(consoantes))
