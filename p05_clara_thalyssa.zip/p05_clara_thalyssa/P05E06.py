medias = []
for i in range(10):
    soma = 0
    for j in range(4):
        soma += float(input(f"Nota {j+1} do aluno {i+1}: "))
    medias.append(soma/4)
aprovados = sum(1 for m in medias if m >= 7)
print("Alunos com média >= 7.0:", aprovados)
