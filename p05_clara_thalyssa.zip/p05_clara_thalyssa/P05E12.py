idades = []
alturas = []
for i in range(30):
    idades.append(int(input("Idade: ")))
    alturas.append(float(input("Altura: ")))
media = sum(alturas)/30
contador = 0
for i in range(30):
    if idades[i] > 13 and alturas[i] < media:
        contador += 1
print("Alunos com mais de 13 anos e altura abaixo da média:", contador)
