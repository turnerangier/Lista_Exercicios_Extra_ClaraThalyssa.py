numeros = []
for i in range(5):
    numeros.append(int(input("Digite um número inteiro: ")))
print("Números:", numeros)
