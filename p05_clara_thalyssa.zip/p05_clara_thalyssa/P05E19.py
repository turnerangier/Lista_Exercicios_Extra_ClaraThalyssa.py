sistemas = [
    "Windows Server",
    "Unix",
    "Linux",
    "Netware",
    "Mac OS",
    "Outro"
]

votos = [0] * 6
total_votos = 0

print("Enquete: Qual o melhor Sistema Operacional para uso em servidores?")
print("1- Windows Server\n2- Unix\n3- Linux\n4- Netware\n5- Mac OS\n6- Outro\n(0 para encerrar)\n")

while True:
    try:
        voto = int(input("Informe seu voto (0 a 6): "))
    except ValueError:
        print("Entrada inválida. Digite um número de 0 a 6.")
        continue

    if voto == 0:
        break
    elif 1 <= voto <= 6:
        votos[voto - 1] += 1
        total_votos += 1
    else:
        print("Valor inválido. Digite um número entre 1 e 6.")

if total_votos == 0:
    print("Nenhum voto foi registrado.")
else:
    print("\nSistema Operacional     Votos   %")
    print("-" * 33)

    maior_voto = max(votos)
    indice_vencedor = votos.index(maior_voto)

    for i in range(6):
        percentual = (votos[i] / total_votos) * 100
        print(f"{sistemas[i]:<23} {votos[i]:<7} {percentual:.0f}%")

    print("-" * 33)
    print(f"Total                   {total_votos}\n")

    vencedor = sistemas[indice_vencedor]
    percentual_vencedor = (maior_voto / total_votos) * 100
    print(f"O Sistema Operacional mais votado foi o {vencedor}, com {maior_voto} votos,")
    print(f"correspondendo a {percentual_vencedor:.0f}% dos votos.")
