notas = []
for i in range(4):
    notas.append(float(input("Digite uma nota: ")))
print("Notas:", notas)
print("Média:", sum(notas)/4)
