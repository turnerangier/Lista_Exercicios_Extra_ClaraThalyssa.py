numeros = []
for i in range(10):
    numeros.append(float(input("Digite um número real: ")))
print("Ordem inversa:", numeros[::-1])
