while True:
    nome = input("Nome do atleta (enter para sair): ")
    if nome == "":
        break

    saltos = []
    for i in range(5):
        distancia = float(input(f"{i+1}º salto: "))
        saltos.append(distancia)

    print(f"\nAtleta: {nome}")
    nomes_saltos = ["Primeiro", "Segundo", "Terceiro", "Quarto", "Quinto"]
    for i in range(5):
        print(f"{nomes_saltos[i]} Salto: {saltos[i]} m")

    media = sum(saltos) / len(saltos)

    print("\nResultado final:")
    print(f"Atleta: {nome}")
    print("Saltos:", " - ".join(f"{s:.1f}" for s in saltos))
    print(f"Média dos saltos: {media:.1f} m\n")
