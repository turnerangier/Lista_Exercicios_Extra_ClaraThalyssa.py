numeros = []
pares = []
impares = []
for i in range(20):
    n = int(input("Digite um número: "))
    numeros.append(n)
    if n % 2 == 0:
        pares.append(n)
    else:
        impares.append(n)
print("Todos:", numeros)
print("Pares:", pares)
print("Ímpares:", impares)
