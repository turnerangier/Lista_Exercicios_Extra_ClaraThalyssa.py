A = [int(input("A: ")) for _ in range(10)]
B = [int(input("B: ")) for _ in range(10)]
C = [int(input("C: ")) for _ in range(10)]
D = []
for i in range(10):
    D += [A[i], B[i], C[i]]
print("Intercalado:", D)
