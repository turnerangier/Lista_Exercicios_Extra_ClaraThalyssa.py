print("Levantamento de Mouses - Suporte de Informática")
print("Digite o número de identificação do mouse e, em seguida, o código do defeito:")
print("1 - necessita da esfera")
print("2 - necessita de limpeza")
print("3 - necessita troca do cabo ou conector")
print("4 - quebrado ou inutilizado")
print("Digite 0 para encerrar.\n")


defeitos = [0, 0, 0, 0]  
total_mouses = 0

while True:
    try:
        id_mouse = int(input("Número de identificação do mouse: "))
        if id_mouse == 0:
            break

        tipo_defeito = int(input("Código do defeito (1 a 4): "))

        if 1 <= tipo_defeito <= 4:
            defeitos[tipo_defeito - 1] += 1
            total_mouses += 1
        else:
            print("Código de defeito inválido. Digite um número entre 1 e 4.")
    except ValueError:
        print("Entrada inválida. Tente novamente com números inteiros.")


descricoes = [
    "necessita da esfera",
    "necessita de limpeza",
    "necessita troca do cabo ou conector",
    "quebrado ou inutilizado"
]


print("\nRelatório do Levantamento")
print(f"Quantidade de mouses: {total_mouses}\n")
print("Situação                             Quantidade  Percentual")
for i in range(4):
    percentual = (defeitos[i] / total_mouses) * 100 if total_mouses > 0 else 0
    print(f"{i + 1} - {descricoes[i]:<33} {defeitos[i]:<10} {percentual:.1f}%")
