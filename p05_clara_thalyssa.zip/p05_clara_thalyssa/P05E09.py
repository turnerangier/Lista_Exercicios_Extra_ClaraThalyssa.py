A = []
for i in range(10):
    A.append(int(input("Digite um número: ")))
soma = sum(x**2 for x in A)
print("Soma dos quadrados:", soma)
