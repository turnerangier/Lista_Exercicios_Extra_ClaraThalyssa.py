perguntas = [
    "Telefonou para a vítima?",
    "Esteve no local do crime?",
    "Mora perto da vítima?",
    "Devia para a vítima?",
    "Já trabalhou com a vítima?"
]
respostas = [input(p + " (s/n): ").lower() for p in perguntas]
pontos = respostas.count("s")

if pontos == 2:
    print("Suspeita")
elif 3 <= pontos <= 4:
    print("Cúmplice")
elif pontos == 5:
    print("Assassino")
else:
    print("Inocente")
