notas = []

while True:
    n = float(input("Digite uma nota (-1 para encerrar): "))
    if n == -1:
        break
    notas.append(n)

print("a) Quantidade de notas lidas:", len(notas))
print("b) Notas na ordem original:", notas)
print("c) Notas na ordem inversa:")
for n in reversed(notas):
    print(n)

soma = sum(notas)
media = soma / len(notas) if notas else 0
acima_media = sum(1 for n in notas if n > media)
abaixo_sete = sum(1 for n in notas if n < 7)

print("d) Soma das notas:", soma)
print("e) Média das notas:", media)
print("f) Quantidade acima da média:", acima_media)
print("g) Quantidade abaixo de 7:", abaixo_sete)
print("h) Programa encerrado. Até logo!")
