salarios = [0] * 9 

while True:
    try:
        vendas = float(input("Digite o valor das vendas brutas (-1 para sair): "))
        if vendas == -1:
            break
        salario = 200 + 0.09 * vendas
        indice = int(salario) // 100 - 2
        if indice >= 8:
            indice = 8
        elif indice < 0:
            indice = 0
        salarios[indice] += 1
    except:
        print("Entrada inválida!")

faixas = [
    "$200 - $299", "$300 - $399", "$400 - $499", "$500 - $599",
    "$600 - $699", "$700 - $799", "$800 - $899", "$900 - $999", "$1000 ou mais"
]

print("\nDistribuição de salários:")
for i in range(9):
    print(f"{faixas[i]}: {salarios[i]} vendedores")
