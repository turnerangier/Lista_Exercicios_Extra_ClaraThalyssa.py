numeros = []
for i in range(5):
    numeros.append(int(input("Digite um número: ")))
soma = sum(numeros)
multi = 1
for n in numeros:
    multi *= n
print("Números:", numeros)
print("Soma:", soma)
print("Multiplicação:", multi)
