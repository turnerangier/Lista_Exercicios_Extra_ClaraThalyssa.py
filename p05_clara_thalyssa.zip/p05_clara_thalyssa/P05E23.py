def bytes_para_mb(bytes_valor):
    return round(bytes_valor / (1024 * 1024), 2)

def calcula_percentual(parte, total):
    return round((parte / total) * 100, 2)

dados = [
    "alexandre      456123789",
    "anderson       1245698456",
    "antonio        123456456",
    "carlos         91257581",
    "cesar          987458",
    "rosemary       789456125"
]

usuarios = []
espacos_mb = []

for linha in dados:
    nome = linha[:15].strip()
    espaco = int(linha[15:].strip())
    espaco_mb = bytes_para_mb(espaco)
    usuarios.append((nome, espaco_mb))
    espacos_mb.append(espaco_mb)

total = sum(espacos_mb)
media = round(total / len(usuarios), 2)

with open("relatório.txt", "w") as rel:
    rel.write("ACME Inc.               Uso do espaço em disco pelos usuários\n")
    rel.write("----------------------------------------------------------------\n")
    rel.write("Nr.  Usuário        Espaço utilizado     % do uso\n\n")
    for i, (nome, espaco) in enumerate(usuarios, 1):
        percentual = calcula_percentual(espaco, total)
        rel.write(f"{i:<4} {nome:<15} {espaco:>10.2f} MB      {percentual:>6.2f}%\n")
    rel.write(f"\nEspaço total ocupado: {total:.2f} MB\n")
    rel.write(f"Espaço médio ocupado: {media:.2f} MB\n")
