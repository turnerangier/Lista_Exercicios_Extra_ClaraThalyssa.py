def calcular_percentual(votos_jogador, total_votos):
    return (votos_jogador * 100) / total_votos


votos = [0] * 24  
total_votos = 0

print("Enquete: Quem foi o melhor jogador?")

while True:
    try:
        numero = int(input("Número do jogador (0=fim): "))
    except ValueError:
        print("Entrada inválida. Digite um número.")
        continue

    if numero == 0:
        break
    if 1 <= numero <= 23:
        votos[numero] += 1
        total_votos += 1
    else:
        print("Informe um valor entre 1 e 23 ou 0 para sair!")

if total_votos == 0:
    print("Nenhum voto computado.")
else:
    print("\nResultado da votação:")
    print(f"Foram computados {total_votos} votos.\n")
    print("Jogador  Votos   %")

    linhas_resultado = []
    melhor_jogador = 0

    for i in range(1, 24):
        if votos[i] > 0:
            percentual = calcular_percentual(votos[i], total_votos)
            print(f"{i:<8} {votos[i]:<7} {percentual:.1f}%")
            linhas_resultado.append(f"{i:<8} {votos[i]:<7} {percentual:.1f}%")

            if votos[i] > votos[melhor_jogador]:
                melhor_jogador = i

    perc_melhor = calcular_percentual(votos[melhor_jogador], total_votos)
    print(f"\nO melhor jogador foi o número {melhor_jogador}, com {votos[melhor_jogador]} votos, "
          f"correspondendo a {perc_melhor:.1f}% do total de votos.")

    
    with open("resultado.txt", "w", encoding="utf-8") as f:
        f.write("Resultado da votação:\n")
        f.write(f"Foram computados {total_votos} votos.\n\n")
        f.write("Jogador  Votos   %\n")
        for linha in linhas_resultado:
            f.write(linha + "\n")
        f.write(f"\nO melhor jogador foi o número {melhor_jogador}, com {votos[melhor_jogador]} votos, "
                f"correspondendo a {perc_melhor:.1f}% do total de votos.\n")
