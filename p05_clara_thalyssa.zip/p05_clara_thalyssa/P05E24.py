import random

resultados = [0] * 6

for _ in range(100):
    lance = random.randint(1, 6)
    resultados[lance - 1] += 1

for i in range(6):
    print(f"Valor {i + 1}: {resultados[i]} vezes")
