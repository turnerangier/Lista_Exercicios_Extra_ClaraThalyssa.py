print("Projeção de Gastos com Abono")
print("=" * 30)

salarios = []
abonos = []

while True:
    try:
        salario = float(input("Salário: "))
        if salario == 0:
            break
        elif salario < 0:
            print("Salário não pode ser negativo.")
            continue
        salarios.append(salario)
    except ValueError:
        print("Digite um valor válido.")

for salario in salarios:
    abono = salario * 0.2
    if abono < 100:
        abono = 100.00
    abonos.append(abono)

print("\nSalário - Abono")
for i in range(len(salarios)):
    print(f"R$ {salarios[i]:.2f} - R$ {abonos[i]:.2f}")

total_colaboradores = len(salarios)
total_abonos = sum(abonos)
quantidade_minimo = abonos.count(100)
maior_abono = max(abonos)

print(f"\nForam processados {total_colaboradores} colaboradores")
print(f"Total gasto com abonos: R$ {total_abonos:.2f}")
print(f"Valor mínimo pago a {quantidade_minimo} colaboradores")
print(f"Maior valor de abono pago: R$ {maior_abono:.2f}")
