A = [int(input("A: ")) for _ in range(10)]
B = [int(input("B: ")) for _ in range(10)]
C = []
for i in range(10):
    C.append(A[i])
    C.append(B[i])
print("Intercalado:", C)
