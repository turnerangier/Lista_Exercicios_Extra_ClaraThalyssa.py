carros = []
consumos = []


print("Comparativo de Consumo de Combustível")

for i in range(5):
    print(f"\nVeículo {i + 1}")
    nome = input("Nome: ").strip()
    while True:
        try:
            km_l = float(input("Km por litro: "))
            if km_l <= 0:
                print("O consumo deve ser maior que 0.")
                continue
            break
        except ValueError:
            print("Digite um número válido.")
    carros.append(nome)
    consumos.append(km_l)


distancia = 1000
preco_gasolina = 2.25

litros_gastos = [distancia / km_l for km_l in consumos]
custos = [litros * preco_gasolina for litros in litros_gastos]


indice_melhor = consumos.index(max(consumos))
carro_mais_economico = carros[indice_melhor]


print("\nRelatório Final")
for i in range(5):
    print(f"{i + 1} - {carros[i]} - {consumos[i]:.1f} - {litros_gastos[i]:.1f} litros - R$ {custos[i]:.2f}")

print(f"\nO menor consumo é do {carros[indice_melhor]}.")
