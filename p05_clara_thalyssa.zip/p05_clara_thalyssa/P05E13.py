meses = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
         "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"]
temps = [float(input(f"Temperatura de {meses[i]}: ")) for i in range(12)]
media = sum(temps)/12
print("Média anual:", media)
for i in range(12):
    if temps[i] > media:
        print(f"{meses[i]}: {temps[i]}")
